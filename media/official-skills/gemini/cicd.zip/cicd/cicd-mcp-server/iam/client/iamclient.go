// Copyright 2024 Google LLC
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     https://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package iamclient

import (
	"context"
	"fmt"
	"strings"

	cloudresourcemanagerv1 "google.golang.org/api/cloudresourcemanager/v1"
	iamv1 "google.golang.org/api/iam/v1"
)

// ServiceAccountList defines a struct to wrap a list of service accounts.
type ServiceAccountList struct {
	Items []*iamv1.ServiceAccount `json:"items"`
}

// RoleBindingList defines a struct to wrap a list of role bindings.
type RoleBindingList struct {
	Items []string `json:"items"`
}

// Client is an interface for interacting with the IAM API.
type IAMClient interface {
    CreateServiceAccount(ctx context.Context, projectID, displayName, accountID string) (*iamv1.ServiceAccount, error)
    AddIAMRoleBinding(ctx context.Context, resourceID, role, member string) (*cloudresourcemanagerv1.Policy, error) // Project-level
    AddServiceAccountRoleBinding(ctx context.Context, resourceID, role, member string) (*iamv1.Policy, error) // SA-level
    ListServiceAccounts(ctx context.Context, projectID string) (*ServiceAccountList, error)
    GetIAMRoleBinding(ctx context.Context, projectID, serviceAccountEmail string) (*RoleBindingList, error)
}

// clientImpl is a client for interacting with the IAM API.
type IAMClientImpl struct {
	iamService *iamv1.Service
	crmService *cloudresourcemanagerv1.Service
}

// NewClient creates a new Client.
func NewClient(ctx context.Context) (IAMClient, error) {
	iamService, err := iamv1.NewService(ctx)
	if err != nil {
		return nil, fmt.Errorf("failed to create iam service: %v", err)
	}
	crmService, err := cloudresourcemanagerv1.NewService(ctx)
	if err != nil {
		return nil, fmt.Errorf("failed to create cloud resource manager service: %v", err)
	}

	return &IAMClientImpl{iamService: iamService, crmService: crmService}, nil
}

// CreateServiceAccount creates a new Google Cloud Platform service account.
func (c *IAMClientImpl) CreateServiceAccount(ctx context.Context, projectID, displayName, accountID string) (*iamv1.ServiceAccount, error) {
	projectPath := fmt.Sprintf("projects/%s", projectID)
	req := &iamv1.CreateServiceAccountRequest{
		AccountId: accountID,
		ServiceAccount: &iamv1.ServiceAccount{
			DisplayName: displayName,
		},
	}

	return c.iamService.Projects.ServiceAccounts.Create(projectPath, req).Context(ctx).Do()
}

// AddIAMRoleBinding adds an IAM role binding to a Google Cloud Platform resource.
func (c *IAMClientImpl) AddIAMRoleBinding(ctx context.Context, resourceID, role, member string) (*cloudresourcemanagerv1.Policy, error) {
	resourceID = strings.TrimPrefix(resourceID, "projects/")
	policy, err := c.crmService.Projects.GetIamPolicy(resourceID, &cloudresourcemanagerv1.GetIamPolicyRequest{}).Context(ctx).Do()
	if err != nil {
		return nil, fmt.Errorf("failed to get iam policy: %v", err)
	}

	// Find the binding for the specific role
	var binding *cloudresourcemanagerv1.Binding
	for _, b := range policy.Bindings {
		if b.Role == role {
			binding = b
			break
		}
	}

	if binding != nil {
		// Check if the member already exists in the binding
		for _, m := range binding.Members {
			if m == member {
				// Member already exists, no need to update
				return policy, nil
			}
		}
		// Add member to existing binding
		binding.Members = append(binding.Members, member)
	} else {
		// Create new binding for the role
		policy.Bindings = append(policy.Bindings, &cloudresourcemanagerv1.Binding{
			Role:    role,
			Members: []string{member},
		})
	}

	setPolicyRequest := &cloudresourcemanagerv1.SetIamPolicyRequest{
		Policy: policy,
	}

	return c.crmService.Projects.SetIamPolicy(resourceID, setPolicyRequest).Context(ctx).Do()
}

// ListServiceAccounts lists all service accounts in a project.
func (c *IAMClientImpl) ListServiceAccounts(ctx context.Context, projectID string) (*ServiceAccountList, error) {
	parent := fmt.Sprintf("projects/%s", projectID)

	resp, err := c.iamService.Projects.ServiceAccounts.List(parent).Context(ctx).Do()
	if err != nil {
		return nil, fmt.Errorf("failed to list service accounts: %v", err)
	}

	return &ServiceAccountList{Items: resp.Accounts}, nil
}

// GetIAMRoleBinding gets the IAM role bindings for a service account.
func (c *IAMClientImpl) GetIAMRoleBinding(ctx context.Context, projectID, serviceAccountEmail string) (*RoleBindingList, error) {
	projectID = strings.TrimPrefix(projectID, "projects/")
	policy, err := c.crmService.Projects.GetIamPolicy(projectID, &cloudresourcemanagerv1.GetIamPolicyRequest{}).Context(ctx).Do()
	if err != nil {
		return nil, fmt.Errorf("failed to get iam policy: %v", err)
	}

	var roles []string

	for _, binding := range policy.Bindings {
		for _, member := range binding.Members {
			if member == fmt.Sprintf("serviceAccount:%s", serviceAccountEmail) {
				roles = append(roles, binding.Role)
			}
		}
	}

	return &RoleBindingList{Items: roles}, nil
}

// AddServiceAccountRoleBinding adds a member to a role on a specific SA and returns the updated Policy.
func (c *IAMClientImpl) AddServiceAccountRoleBinding(ctx context.Context, resourceID, role, member string) (*iamv1.Policy, error) {
    // 1. Get the current policy (includes the ETag)
    policy, err := c.iamService.Projects.ServiceAccounts.GetIamPolicy(resourceID).Context(ctx).Do()
    if err != nil {
        return nil, fmt.Errorf("failed to get iam policy: %w", err)
    }

    // 2. Modify the policy
    updated := false
    for _, binding := range policy.Bindings {
        if binding.Role == role {
            for _, m := range binding.Members {
                if m == member {
                    return policy, nil // Already exists, exit early to save an API call
                }
            }
            binding.Members = append(binding.Members, member)
            updated = true
            break
        }
    }

    if !updated {
        policy.Bindings = append(policy.Bindings, &iamv1.Binding{
            Role:    role,
            Members: []string{member},
        })
    }

    // 3. Set the policy (The ETag in 'policy' ensures we don't overwrite concurrent changes)
    request := &iamv1.SetIamPolicyRequest{
        Policy: policy,
    }
    
    updatedPolicy, err := c.iamService.Projects.ServiceAccounts.SetIamPolicy(resourceID, request).Context(ctx).Do()
    if err != nil {
        return nil, fmt.Errorf("failed to set iam policy: %w", err)
    }

    return updatedPolicy, nil
}