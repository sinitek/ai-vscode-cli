// Copyright 2024 Google LLC
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     https://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package cloudbuild

import (
	"context"
	"fmt"
	"regexp"
	"strings"

	"github.com/modelcontextprotocol/go-sdk/mcp"

	cloudbuildclient "cicd-mcp-server/cloudbuild/client"
	iamclient "cicd-mcp-server/iam/client"
	resourcemanagerclient "cicd-mcp-server/resourcemanager/client"

	cloudbuildpb "cloud.google.com/go/cloudbuild/apiv1/v2/cloudbuildpb"
)

// Handler holds the clients for the cloudbuild service.
type Handler struct {
	CbClient cloudbuildclient.CloudBuildClient
	IClient  iamclient.IAMClient
	RClient  resourcemanagerclient.ResourcemanagerClient
}

// Register registers the cloudbuild tools with the MCP server.
func (h *Handler) Register(server *mcp.Server) {
	addCreateTriggerTool(server, h.CbClient, h.IClient, h.RClient)
	addRunTriggerTool(server, h.CbClient)
	addListTriggersTool(server, h.CbClient)
	addListBuildsTool(server, h.CbClient)
	addGetBuildInfoTool(server, h.CbClient)
	addStartBuildTool(server, h.CbClient)
}

type RunTriggerArgs struct {
	ProjectID string `json:"project_id" jsonschema:"The Google Cloud project ID."`
	Location  string `json:"location" jsonschema:"The Google Cloud location for the trigger."`
	TriggerID string `json:"trigger_id" jsonschema:"The ID of the trigger."`
	Branch    string `json:"branch,omitempty" jsonschema:"The branch to to run the trigger at. Should be regex e.g. '^main$'"`
	Tag       string `json:"tag,omitempty" jsonschema:"The tag to to run the trigger at. Should be regex e.g. '^nightly$'"`
	CommitSha string `json:"commit_sha,omitempty" jsonschema:"The commit sha to run the trigger at. Exact commit sha e.g. 12ede13"`
}

var runTriggerToolFunc func(ctx context.Context, req *mcp.CallToolRequest, args RunTriggerArgs) (*mcp.CallToolResult, any, error)

func addRunTriggerTool(server *mcp.Server, cbClient cloudbuildclient.CloudBuildClient) {
	runTriggerToolFunc = func(ctx context.Context, req *mcp.CallToolRequest, args RunTriggerArgs) (*mcp.CallToolResult, any, error) {
		res, err := cbClient.RunBuildTrigger(ctx, args.ProjectID, args.Location, args.TriggerID, args.Branch, args.Tag, args.CommitSha)
		if err != nil {
			return &mcp.CallToolResult{}, nil, fmt.Errorf("failed to run trigger: %w", err)
		}
		return &mcp.CallToolResult{}, res, nil
	}
	mcp.AddTool(server, &mcp.Tool{Name: "run_build_trigger", Description: "Runs a Cloud Build trigger."}, runTriggerToolFunc)
}

type ListTriggersArgs struct {
	ProjectID string `json:"project_id" jsonschema:"The Google Cloud project ID."`
	Location  string `json:"location" jsonschema:"The Google Cloud location for the triggers."`
}

var listTriggersToolFunc func(ctx context.Context, req *mcp.CallToolRequest, args ListTriggersArgs) (*mcp.CallToolResult, any, error)

func addListTriggersTool(server *mcp.Server, cbClient cloudbuildclient.CloudBuildClient) {
	listTriggersToolFunc = func(ctx context.Context, req *mcp.CallToolRequest, args ListTriggersArgs) (*mcp.CallToolResult, any, error) {
		res, err := cbClient.ListBuildTriggers(ctx, args.ProjectID, args.Location)
		if err != nil {
			return &mcp.CallToolResult{}, nil, fmt.Errorf("failed to list triggers: %w", err)
		}
		return &mcp.CallToolResult{}, map[string]any{"triggers": res}, nil
	}
	mcp.AddTool(server, &mcp.Tool{Name: "list_build_triggers", Description: "Lists all Cloud Build triggers in a given location."}, listTriggersToolFunc)
}

type CreateTriggerArgs struct {
	ProjectID      string `json:"project_id" jsonschema:"The Google Cloud project ID."`
	Location       string `json:"location" jsonschema:"The Google Cloud location for the trigger."`
	TriggerID      string `json:"trigger_id" jsonschema:"The ID of the trigger."`
	RepoLink       string `json:"repo_link" jsonschema:"The Developer Connect repository link, use dev connect setup repo to create a connect and repo link"`
	ServiceAccount string `json:"service_account" jsonschema:"The service account to use for the build. E.g. serviceAccount:name@project-id.iam.gserviceaccount.com. This MUST be a dedicated service account, not the default Compute Engine service account."`
	Branch         string `json:"branch,omitempty" jsonschema:"Create builds on push to branch. Should be regex e.g. '^main$'"`
	Tag            string `json:"tag,omitempty" jsonschema:"Create builds on new tag push. Should be regex e.g. '^nightly$'"`
}

var createTriggerToolFunc func(ctx context.Context, req *mcp.CallToolRequest, args CreateTriggerArgs) (*mcp.CallToolResult, any, error)

func addCreateTriggerTool(server *mcp.Server, cbClient cloudbuildclient.CloudBuildClient, iamClient iamclient.IAMClient, rmClient resourcemanagerclient.ResourcemanagerClient) {
	createTriggerToolFunc = func(ctx context.Context, req *mcp.CallToolRequest, args CreateTriggerArgs) (*mcp.CallToolResult, any, error) {
		if args.ServiceAccount == "" {
			return &mcp.CallToolResult{}, nil, fmt.Errorf("service_account is required and must be a dedicated service account")
		}
		if !strings.HasPrefix(args.ServiceAccount, "serviceAccount:") {
			args.ServiceAccount = fmt.Sprintf("serviceAccount:%s", args.ServiceAccount)
		}
		if !IsValidServiceAccount(args.ServiceAccount) {
			return &mcp.CallToolResult{}, nil, fmt.Errorf("service account needs to be of the form serviceAccount:name@project-id.iam.gserviceaccount.com")
		}
		resolvedSA, err := setPermissionsForCloudBuildSA(ctx, args.ProjectID, args.ServiceAccount, rmClient, iamClient)
		if err != nil {
			return &mcp.CallToolResult{}, nil, fmt.Errorf("failed to grant necessary permissions for the Cloud build service account: %w", err)
		}
		res, err := cbClient.CreateBuildTrigger(ctx, args.ProjectID, args.Location, args.TriggerID, args.RepoLink, args.Branch, args.Tag, resolvedSA)
		if err != nil {
			return &mcp.CallToolResult{}, nil, fmt.Errorf("failed to create trigger: %w", err)
		}
		return &mcp.CallToolResult{}, res, nil
	}
	mcp.AddTool(server, &mcp.Tool{Name: "create_build_trigger", Description: "Creates a new Cloud Build trigger."}, createTriggerToolFunc)
}

// setPermissionsForCloudBuildSA resolves the SA and grants it a role.
func setPermissionsForCloudBuildSA(ctx context.Context, projectID, serviceAccount string, rmClient resourcemanagerclient.ResourcemanagerClient, iamClient iamclient.IAMClient) (string, error) {
	resolvedSA := serviceAccount

	// If the serviceAccount prefix is not there, add it.
	if !strings.HasPrefix(resolvedSA, "serviceAccount:") {
		resolvedSA = fmt.Sprintf("serviceAccount:%s", resolvedSA)
	}

	// 1. Roles for the Cloud Build Service Account (Project Level)
	gcbSARoles := []string{
		"roles/artifactregistry.writer",
		"roles/cloudbuild.builds.editor",
		"roles/developerconnect.tokenAccessor",
		"roles/logging.logWriter",
		"roles/run.developer",
		"roles/serviceusage.serviceUsageConsumer",
		"roles/storage.admin",
	}
	for _, r := range gcbSARoles {
		_, err := iamClient.AddIAMRoleBinding(ctx, fmt.Sprintf("projects/%s", projectID), r, resolvedSA)
		if err != nil {
			return "", fmt.Errorf("unable to add role %s to member %s on project %s err: %w", r, resolvedSA, projectID, err)
		}
	}

	projectNumber, err := rmClient.ToProjectNumber(ctx, projectID)
	if err != nil {
		return "", fmt.Errorf("unable to resolve project id to number: %w", err)
	}

	// 2. Roles for the Developer Connect Service Agent (Project Level)
	dcP4sa := fmt.Sprintf("serviceAccount:service-%d@gcp-sa-devconnect.iam.gserviceaccount.com", projectNumber)
	_, err = iamClient.AddIAMRoleBinding(ctx, fmt.Sprintf("projects/%s", projectID), "roles/secretmanager.admin", dcP4sa)
	if err != nil {
		return "", fmt.Errorf("unable to add secretmanager.admin role to Developer Connect P4SA %s: %w", dcP4sa, err)
	}

	// 3. Roles for the Cloud Build Service Agent (Project Level)
	gcbP4sa := fmt.Sprintf("serviceAccount:service-%d@gcp-sa-cloudbuild.iam.gserviceaccount.com", projectNumber)
	gcbP4saRoles := []string{
		"roles/cloudbuild.serviceAgent",
		"roles/developerconnect.tokenAccessor",
	}
	for _, r := range gcbP4saRoles {
		_, err := iamClient.AddIAMRoleBinding(ctx, fmt.Sprintf("projects/%s", projectID), r, gcbP4sa)
		if err != nil {
			return "", fmt.Errorf("unable to add role %s to Cloud Build P4SA %s on project %s err: %w", r, gcbP4sa, projectID, err)
		}
	}

	// 4. Grant Cloud Build Service Agent permissions to impersonate the Cloud Run SA (Default Compute SA)
	defaultComputeSA := fmt.Sprintf("serviceAccount:%d-compute@developer.gserviceaccount.com", projectNumber)
	resource := fmt.Sprintf("projects/%s/serviceAccounts/%s", projectID, strings.TrimPrefix(defaultComputeSA, "serviceAccount:"))
	_, err = iamClient.AddServiceAccountRoleBinding(ctx, resource, "roles/iam.serviceAccountUser", gcbP4sa)
	if err != nil {
		return "", fmt.Errorf("unable to add iam.serviceAccountUser role to Cloud Build P4SA %s on SA %s err: %w", gcbP4sa, defaultComputeSA, err)
	}

	// 5. Grant Cloud Build Service Agent permissions to impersonate the SA passed in (SA that is going to run the build)
	r := fmt.Sprintf("projects/%s/serviceAccounts/%s", projectID, strings.TrimPrefix(resolvedSA, "serviceAccount:"))
	_, err = iamClient.AddServiceAccountRoleBinding(ctx, r, "roles/iam.serviceAccountUser", gcbP4sa)
	if err != nil {
		return "", fmt.Errorf("unable to add iam.serviceAccountUser role to Cloud Build P4SA %s on SA %s err: %w", gcbP4sa, r, err)
	}

	return resolvedSA, nil
}

// IsValidServiceAccount checks if the string follows the specific GCP service account format.
func IsValidServiceAccount(sa string) bool {
	var saRegex = regexp.MustCompile(`^serviceAccount:[a-z0-9-]+@[a-z0-9-]+\.iam\.gserviceaccount\.com$`)
	return saRegex.MatchString(sa)
}

type ListBuildsArgs struct {
	ProjectID string `json:"project_id" jsonschema:"The Google Cloud project ID."`
	Location  string `json:"location" jsonschema:"The Google Cloud location for the builds."`
}

type GetBuildInfoArgs struct {
	ProjectID string `json:"project_id" jsonschema:"The Google Cloud project ID."`
	Location  string `json:"location" jsonschema:"The Google Cloud location for the build."`
	BuildID   string `json:"build_id" jsonschema:"The ID of the build."`
}

type StartBuildArgs struct {
	ProjectID string `json:"project_id" jsonschema:"The Google Cloud project ID."`
	Location  string `json:"location" jsonschema:"The Google Cloud location for the build."`
	Bucket    string `json:"bucket" jsonschema:"The Cloud Storage bucket where the source is located."`
	Object    string `json:"object" jsonschema:"The Cloud Storage object (file) where the source is located."`
}

func addListBuildsTool(server *mcp.Server, cbClient cloudbuildclient.CloudBuildClient) {
	listBuildsToolFunc := func(ctx context.Context, req *mcp.CallToolRequest, args ListBuildsArgs) (*mcp.CallToolResult, any, error) {
		res, err := cbClient.ListBuilds(ctx, args.ProjectID, args.Location)
		if err != nil {
			return &mcp.CallToolResult{}, nil, fmt.Errorf("failed to list builds: %w", err)
		}
		return &mcp.CallToolResult{}, map[string]any{"builds": res}, nil
	}
	mcp.AddTool(server, &mcp.Tool{Name: "list_builds", Description: "Lists all Cloud Builds in a given location and project."}, listBuildsToolFunc)
}

func addGetBuildInfoTool(server *mcp.Server, cbClient cloudbuildclient.CloudBuildClient) {
	getBuildInfoToolFunc := func(ctx context.Context, req *mcp.CallToolRequest, args GetBuildInfoArgs) (*mcp.CallToolResult, any, error) {
		res, err := cbClient.GetBuildInfo(ctx, args.ProjectID, args.Location, args.BuildID)
		if err != nil {
			return &mcp.CallToolResult{}, nil, fmt.Errorf("failed to get build info: %w", err)
		}
		return &mcp.CallToolResult{}, res, nil
	}
	mcp.AddTool(server, &mcp.Tool{Name: "get_build_details", Description: "Gets information about a specific Cloud Build."}, getBuildInfoToolFunc)
}

func addStartBuildTool(server *mcp.Server, cbClient cloudbuildclient.CloudBuildClient) {
	startBuildToolFunc := func(ctx context.Context, req *mcp.CallToolRequest, args StartBuildArgs) (*mcp.CallToolResult, any, error) {
		source := &cloudbuildpb.Source{
			Source: &cloudbuildpb.Source_StorageSource{
				StorageSource: &cloudbuildpb.StorageSource{
					Bucket: args.Bucket,
					Object: args.Object,
				},
			},
		}
		res, err := cbClient.StartBuild(ctx, args.ProjectID, args.Location, source)
		if err != nil {
			return &mcp.CallToolResult{}, nil, fmt.Errorf("failed to start build: %w", err)
		}
		return &mcp.CallToolResult{}, res, nil
	}
	mcp.AddTool(server, &mcp.Tool{Name: "start_build", Description: "Starts a new Cloud Build from a source in Google Cloud Storage."}, startBuildToolFunc)
}
