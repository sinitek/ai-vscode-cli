# Changelog

## [0.6.0](https://github.com/gemini-cli-extensions/mcp-toolbox/compare/0.5.0...0.6.0) (2026-02-18)


### ⚠ BREAKING CHANGES

* Update/add detailed telemetry for mcp endpoint compliant with OTEL semantic convention ([mcp-toolbox#​1987](https://redirect.github.com/googleapis/mcp-toolbox/issues/1987)) ([478a0bd](https://redirect.github.com/googleapis/mcp-toolbox/commit/478a0bdb59288c1213f83862f95a698b4c2c0aab))
* Update configuration file v2 ([mcp-toolbox#​2369](https://redirect.github.com/googleapis/mcp-toolbox/issues/2369))([293c1d6](https://redirect.github.com/googleapis/mcp-toolbox/commit/293c1d6889c39807855ba5e01d4c13ba2a4c50ce))

### Features

* **cli/invoke:** Add support for direct tool invocation from CLI ([mcp-toolbox#​2353](https://redirect.github.com/googleapis/mcp-toolbox/issues/2353)) ([6e49ba4](https://redirect.github.com/googleapis/mcp-toolbox/commit/6e49ba436ef2390c13feaf902b29f5907acffb57)) ([13f5204](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/13f5204cb88aff261c741da4a521a0321cc7b015))
* **cli/skills:** Add support for generating agent skills from toolset ([mcp-toolbox#​2392](https://redirect.github.com/googleapis/mcp-toolbox/issues/2392)) ([80ef346](https://redirect.github.com/googleapis/mcp-toolbox/commit/80ef34621453b77bdf6a6016c354f102a17ada04)) ([13f5204](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/13f5204cb88aff261c741da4a521a0321cc7b015))
* **cloud-logging-admin:** Add source, tools, integration test and docs ([mcp-toolbox#​2137](https://redirect.github.com/googleapis/mcp-toolbox/issues/2137)) ([252fc30](https://redirect.github.com/googleapis/mcp-toolbox/commit/252fc3091af10d25d8d7af7e047b5ac87a5dd041)) ([13f5204](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/13f5204cb88aff261c741da4a521a0321cc7b015))
* **cockroachdb:** Add CockroachDB integration with cockroach-go ([mcp-toolbox#​2006](https://redirect.github.com/googleapis/mcp-toolbox/issues/2006)) ([1fdd99a](https://redirect.github.com/googleapis/mcp-toolbox/commit/1fdd99a9b609a5e906acce414226ff44d75d5975)) ([13f5204](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/13f5204cb88aff261c741da4a521a0321cc7b015))
* **prebuiltconfigs/alloydb-omni:** Implement Alloydb omni dataplane tools ([mcp-toolbox#​2340](https://redirect.github.com/googleapis/mcp-toolbox/issues/2340)) ([e995349](https://redirect.github.com/googleapis/mcp-toolbox/commit/e995349ea0756c700d188b8f04e9459121219f0c)) ([13f5204](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/13f5204cb88aff261c741da4a521a0321cc7b015))
* **server:** Add Tool call error categories ([mcp-toolbox#​2387](https://redirect.github.com/googleapis/mcp-toolbox/issues/2387)) ([32cb4db](https://redirect.github.com/googleapis/mcp-toolbox/commit/32cb4db712d27579c1bf29e61cbd0bed02286c28)) ([13f5204](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/13f5204cb88aff261c741da4a521a0321cc7b015))
* **tools/looker:** support `looker-validate-project` tool ([mcp-toolbox#​2430](https://redirect.github.com/googleapis/mcp-toolbox/issues/2430)) ([a15a128](https://redirect.github.com/googleapis/mcp-toolbox/commit/a15a12873f936b0102aeb9500cc3bcd71bb38c34)) ([13f5204](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/13f5204cb88aff261c741da4a521a0321cc7b015))
* Update configuration file v2 ([mcp-toolbox#​2369](https://redirect.github.com/googleapis/mcp-toolbox/issues/2369))([293c1d6](https://redirect.github.com/googleapis/mcp-toolbox/commit/293c1d6889c39807855ba5e01d4c13ba2a4c50ce)) ([13f5204](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/13f5204cb88aff261c741da4a521a0321cc7b015))
* Update/add detailed telemetry for mcp endpoint compliant with OTEL semantic convention ([mcp-toolbox#​1987](https://redirect.github.com/googleapis/mcp-toolbox/issues/1987)) ([478a0bd](https://redirect.github.com/googleapis/mcp-toolbox/commit/478a0bdb59288c1213f83862f95a698b4c2c0aab)) ([13f5204](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/13f5204cb88aff261c741da4a521a0321cc7b015))


### Bug Fixes

* **dataplex:** Capture GCP HTTP errors in MCP Toolbox ([mcp-toolbox#​2347](https://redirect.github.com/googleapis/mcp-toolbox/issues/2347)) ([1d7c498](https://redirect.github.com/googleapis/mcp-toolbox/commit/1d7c4981164c34b4d7bc8edecfd449f57ad11e15)) ([13f5204](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/13f5204cb88aff261c741da4a521a0321cc7b015))
* **sources/cockroachdb:** Update kind to type ([mcp-toolbox#​2465](https://redirect.github.com/googleapis/mcp-toolbox/issues/2465)) ([2d341ac](https://redirect.github.com/googleapis/mcp-toolbox/commit/2d341acaa61c3c1fe908fceee8afbd90fb646d3a)) ([13f5204](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/13f5204cb88aff261c741da4a521a0321cc7b015))
* Surface Dataplex API errors in MCP results ([mcp-toolbox#​2347](https://redirect.github.com/googleapis/mcp-toolbox/pull/2347))([1d7c498](https://redirect.github.com/googleapis/mcp-toolbox/commit/1d7c4981164c34b4d7bc8edecfd449f57ad11e15)) ([13f5204](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/13f5204cb88aff261c741da4a521a0321cc7b015))

## [0.5.0](https://github.com/gemini-cli-extensions/mcp-toolbox/compare/0.4.0...0.5.0) (2026-01-28)


### ⚠ BREAKING CHANGES

* **tools/cloudgda:** Update description and parameter name for cloudgda tool ([mcp-toolbox#​2288](https://redirect.github.com/googleapis/mcp-toolbox/issues/2288)) ([6b02591](https://redirect.github.com/googleapis/mcp-toolbox/commit/6b025917032394a66840488259db8ff2c3063016))
* Validate tool naming ([mcp-toolbox#​2305](https://redirect.github.com/googleapis/mcp-toolbox/issues/2305)) ([5054212](https://redirect.github.com/googleapis/mcp-toolbox/commit/5054212fa43017207fe83275d27b9fbab96e8ab5))

### Features

* **embeddingModel:** Add embedding model to MCP handler ([mcp-toolbox#​2310](https://redirect.github.com/googleapis/mcp-toolbox/issues/2310)) ([e4f60e5](https://redirect.github.com/googleapis/mcp-toolbox/commit/e4f60e56335b755ef55b9553d3f40b31858ec8d9)) ([f6278cd](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/f6278cd58b9715b8dec5e95cecd334af10a69823))
* **prebuilt/cloud-sql:** Add create backup tool for Cloud SQL ([mcp-toolbox#​2141](https://redirect.github.com/googleapis/mcp-toolbox/issues/2141)) ([8e0fb03](https://redirect.github.com/googleapis/mcp-toolbox/commit/8e0fb0348315a80f63cb47b3c7204869482448f4)) ([f6278cd](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/f6278cd58b9715b8dec5e95cecd334af10a69823))
* **prebuilt/cloud-sql:** Add restore backup tool for Cloud SQL ([mcp-toolbox#​2171](https://redirect.github.com/googleapis/mcp-toolbox/issues/2171)) ([00c3e6d](https://redirect.github.com/googleapis/mcp-toolbox/commit/00c3e6d8cba54e2ab6cb271c7e6b378895df53e1)) ([f6278cd](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/f6278cd58b9715b8dec5e95cecd334af10a69823))
* **sources/bigquery:** Make maximum rows returned from queries configurable ([mcp-toolbox#​2262](https://redirect.github.com/googleapis/mcp-toolbox/issues/2262)) ([4abf0c3](https://redirect.github.com/googleapis/mcp-toolbox/commit/4abf0c39e717d53b22cc61efb65e09928c598236)) ([f6278cd](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/f6278cd58b9715b8dec5e95cecd334af10a69823))
* **tools:** Add `valueFromParam` support to Tool config ([mcp-toolbox#​2333](https://redirect.github.com/googleapis/mcp-toolbox/issues/2333)) ([15101b1](https://redirect.github.com/googleapis/mcp-toolbox/commit/15101b1edbe2b85a4a5f9f819c23cf83138f4ee1)) ([f6278cd](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/f6278cd58b9715b8dec5e95cecd334af10a69823))
* **tools/cloudgda:** Update description and parameter name for cloudgda tool ([mcp-toolbox#​2288](https://redirect.github.com/googleapis/mcp-toolbox/issues/2288)) ([6b02591](https://redirect.github.com/googleapis/mcp-toolbox/commit/6b025917032394a66840488259db8ff2c3063016)) ([f6278cd](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/f6278cd58b9715b8dec5e95cecd334af10a69823))
* Add new `user-agent-metadata` flag ([mcp-toolbox#​2302](https://redirect.github.com/googleapis/mcp-toolbox/issues/2302)) ([adc9589](https://redirect.github.com/googleapis/mcp-toolbox/commit/adc9589766904d9e3cbe0a6399222f8d4bb9d0cc)) ([f6278cd](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/f6278cd58b9715b8dec5e95cecd334af10a69823))
* Add remaining flag to Toolbox server in MCP registry ([mcp-toolbox#​2272](https://redirect.github.com/googleapis/mcp-toolbox/issues/2272)) ([5e0999e](https://redirect.github.com/googleapis/mcp-toolbox/commit/5e0999ebf5cdd9046e96857738254b2e0561b6d2)) ([f6278cd](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/f6278cd58b9715b8dec5e95cecd334af10a69823))
* Support combining multiple prebuilt configurations ([mcp-toolbox#​2295](https://redirect.github.com/googleapis/mcp-toolbox/issues/2295)) ([e535b37](https://redirect.github.com/googleapis/mcp-toolbox/commit/e535b372ea81864d644a67135a1b07e4e519b4b4)) ([f6278cd](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/f6278cd58b9715b8dec5e95cecd334af10a69823))
* Support MCP specs version 2025-11-25 ([mcp-toolbox#​2303](https://redirect.github.com/googleapis/mcp-toolbox/issues/2303)) ([4d23a3b](https://redirect.github.com/googleapis/mcp-toolbox/commit/4d23a3bbf2797b1f7fe328aeb5789e778121da23)) ([f6278cd](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/f6278cd58b9715b8dec5e95cecd334af10a69823))
* Validate tool naming ([mcp-toolbox#​2305](https://redirect.github.com/googleapis/mcp-toolbox/issues/2305)) ([5054212](https://redirect.github.com/googleapis/mcp-toolbox/commit/5054212fa43017207fe83275d27b9fbab96e8ab5)) ([f6278cd](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/f6278cd58b9715b8dec5e95cecd334af10a69823))


### Bug Fixes

* **tools/cloudhealthcare:** Add check for client authorization before retrieving token string ([mcp-toolbox#​2327](https://redirect.github.com/googleapis/mcp-toolbox/issues/2327)) ([c25a233](https://redirect.github.com/googleapis/mcp-toolbox/commit/c25a2330fea2ac382a398842c9e572e4e19bcb08)) ([f6278cd](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/f6278cd58b9715b8dec5e95cecd334af10a69823))

## [0.4.0](https://github.com/gemini-cli-extensions/mcp-toolbox/compare/0.3.1...0.4.0) (2026-01-15)


### ⚠ BREAKING CHANGES

* **serverless-spark:** add URLs to create batch tool outputs
* **serverless-spark:** add URLs to list\_batches output
* **serverless-spark:** add Cloud Console and Logging URLs to get\_batch
* **tools/postgres:** Add additional filter params for existing postgres tools ([mcp-toolbox#​2033](https://redirect.github.com/googleapis/mcp-toolbox/issues/2033))

### Features

* **looker/tools:** Enhance dashboard creation with dashboard filters ([mcp-toolbox#​2133](https://redirect.github.com/googleapis/mcp-toolbox/issues/2133)) ([285aa46](https://redirect.github.com/googleapis/mcp-toolbox/commit/285aa46b887d9acb2da8766e107bbf1ab75b8812)) ([8ac5edd](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/8ac5edd3cb8254047ee77a714025d5092bc77dc6))
* **prebuilt/cloud-sql-mysql:** Update CSQL MySQL prebuilt tools to use IAM ([mcp-toolbox#​2202](https://redirect.github.com/googleapis/mcp-toolbox/issues/2202)) ([731a32e](https://redirect.github.com/googleapis/mcp-toolbox/commit/731a32e5360b4d6862d81fcb27d7127c655679a8)) ([8ac5edd](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/8ac5edd3cb8254047ee77a714025d5092bc77dc6))
* **serverless-spark:** add Cloud Console and Logging URLs to get\_batch ([8ac5edd](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/8ac5edd3cb8254047ee77a714025d5092bc77dc6))
* **serverless-spark:** Add Cloud Console and Logging URLs to get\_batch ([e29c061](https://redirect.github.com/googleapis/mcp-toolbox/commit/e29c0616d6b9ecda2badcaf7b69614e511ac031b)) ([8ac5edd](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/8ac5edd3cb8254047ee77a714025d5092bc77dc6))
* **serverless-spark:** add URLs to create batch tool outputs ([8ac5edd](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/8ac5edd3cb8254047ee77a714025d5092bc77dc6))
* **serverless-spark:** Add URLs to create batch tool outputs ([c6ccf4b](https://redirect.github.com/googleapis/mcp-toolbox/commit/c6ccf4bd87026484143a2d0f5527b2edab03b54a)) ([8ac5edd](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/8ac5edd3cb8254047ee77a714025d5092bc77dc6))
* **serverless-spark:** add URLs to list\_batches output ([8ac5edd](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/8ac5edd3cb8254047ee77a714025d5092bc77dc6))
* **serverless-spark:** Add URLs to list\_batches output ([5605eab](https://redirect.github.com/googleapis/mcp-toolbox/commit/5605eabd696696ade07f52431a28ef65c0fb1f77)) ([8ac5edd](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/8ac5edd3cb8254047ee77a714025d5092bc77dc6))
* **snowflake:** Add Snowflake Source and Tools ([mcp-toolbox#​858](https://redirect.github.com/googleapis/mcp-toolbox/issues/858)) ([b706b5b](https://redirect.github.com/googleapis/mcp-toolbox/commit/b706b5bc685aeda277f277868bae77d38d5fd7b6)) ([8ac5edd](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/8ac5edd3cb8254047ee77a714025d5092bc77dc6))
* **source/cloudsqlmysql:** Add support for IAM authentication in Cloud SQL MySQL source ([mcp-toolbox#​2050](https://redirect.github.com/googleapis/mcp-toolbox/issues/2050)) ([af3d3c5](https://redirect.github.com/googleapis/mcp-toolbox/commit/af3d3c52044bea17781b89ce4ab71ff0f874ac20)) ([8ac5edd](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/8ac5edd3cb8254047ee77a714025d5092bc77dc6))
* **sources/bigquery:** Make credentials scope configurable ([mcp-toolbox#​2210](https://redirect.github.com/googleapis/mcp-toolbox/issues/2210)) ([a450600](https://redirect.github.com/googleapis/mcp-toolbox/commit/a4506009b93771b77fb05ae97044f914967e67ed)) ([8ac5edd](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/8ac5edd3cb8254047ee77a714025d5092bc77dc6))
* **sources/cloud-gemini-data-analytics:** Add the Gemini Data Analytics (GDA) integration for DB NL2SQL conversion to Toolbox ([mcp-toolbox#​2181](https://redirect.github.com/googleapis/mcp-toolbox/issues/2181)) ([aa270b2](https://redirect.github.com/googleapis/mcp-toolbox/commit/aa270b2630da2e3d618db804ca95550445367dbc)) ([8ac5edd](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/8ac5edd3cb8254047ee77a714025d5092bc77dc6))
* **sources/mariadb:** Add MariaDB source and MySQL tools integration ([mcp-toolbox#​1908](https://redirect.github.com/googleapis/mcp-toolbox/issues/1908)) ([3b40fea](https://redirect.github.com/googleapis/mcp-toolbox/commit/3b40fea25edae607e02c1e8fc2b0c957fa2c8e9a)) ([8ac5edd](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/8ac5edd3cb8254047ee77a714025d5092bc77dc6))
* **sources/oracle:** Add Oracle OCI and Wallet support ([mcp-toolbox#​1945](https://redirect.github.com/googleapis/mcp-toolbox/issues/1945)) ([8ea39ec](https://redirect.github.com/googleapis/mcp-toolbox/commit/8ea39ec32fbbaa97939c626fec8c5d86040ed464)) ([8ac5edd](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/8ac5edd3cb8254047ee77a714025d5092bc77dc6))
* **sources/trino:** Add ssl verification options and fix docs example ([mcp-toolbox#​2155](https://redirect.github.com/googleapis/mcp-toolbox/issues/2155)) ([4a4cf1e](https://redirect.github.com/googleapis/mcp-toolbox/commit/4a4cf1e712b671853678dba99c4dc49dd4fc16a2)) ([8ac5edd](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/8ac5edd3cb8254047ee77a714025d5092bc77dc6))
* **tools/looker:** Add ability to set destination folder with `make_look` and `make_dashboard`. ([mcp-toolbox#​2245](https://redirect.github.com/googleapis/mcp-toolbox/issues/2245)) ([eb79339](https://redirect.github.com/googleapis/mcp-toolbox/commit/eb793398cd1cc4006d9808ccda5dc7aea5e92bd5)) ([8ac5edd](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/8ac5edd3cb8254047ee77a714025d5092bc77dc6))
* **tools/mysql-get-query-plan:** Add new `mysql-get-query-plan` tool for MySQL source ([mcp-toolbox#​2123](https://redirect.github.com/googleapis/mcp-toolbox/issues/2123)) ([0641da0](https://redirect.github.com/googleapis/mcp-toolbox/commit/0641da0353857317113b2169e547ca69603ddfde)) ([8ac5edd](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/8ac5edd3cb8254047ee77a714025d5092bc77dc6))
* **tools/postgres:** Add additional filter params for existing postgres tools ([mcp-toolbox#​2033](https://redirect.github.com/googleapis/mcp-toolbox/issues/2033)) ([8ac5edd](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/8ac5edd3cb8254047ee77a714025d5092bc77dc6))
* **tools/postgres:** Add additional filter params for existing postgres tools ([mcp-toolbox#​2033](https://redirect.github.com/googleapis/mcp-toolbox/issues/2033)) ([489117d](https://redirect.github.com/googleapis/mcp-toolbox/commit/489117d74711ac9260e7547163ca463eb45eeaa2)) ([8ac5edd](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/8ac5edd3cb8254047ee77a714025d5092bc77dc6))
* **tools/postgres:** Add list-table-stats-tool to list table statistics. ([mcp-toolbox#​2055](https://redirect.github.com/googleapis/mcp-toolbox/issues/2055)) ([78b02f0](https://redirect.github.com/googleapis/mcp-toolbox/commit/78b02f08c3cc3062943bb2f91cf60d5149c8d28d)) ([8ac5edd](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/8ac5edd3cb8254047ee77a714025d5092bc77dc6))
* **tools/postgres:** Add list\_pg\_settings, list\_database\_stats tools for postgres ([mcp-toolbox#​2030](https://redirect.github.com/googleapis/mcp-toolbox/issues/2030)) ([32367a4](https://redirect.github.com/googleapis/mcp-toolbox/commit/32367a472fae9653fed7f126428eba0252978bd5)) ([8ac5edd](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/8ac5edd3cb8254047ee77a714025d5092bc77dc6))
* **tools/postgres:** Add new postgres-list-roles tool ([mcp-toolbox#​2038](https://redirect.github.com/googleapis/mcp-toolbox/issues/2038)) ([bea9705](https://redirect.github.com/googleapis/mcp-toolbox/commit/bea97054502cfa236aa10e2ebc8ff58eb00ad035)) ([8ac5edd](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/8ac5edd3cb8254047ee77a714025d5092bc77dc6))
* **tools/postgressql:** Add Parameter `embeddedBy` config support ([mcp-toolbox#​2151](https://redirect.github.com/googleapis/mcp-toolbox/issues/2151)) ([17b70cc](https://redirect.github.com/googleapis/mcp-toolbox/commit/17b70ccaa754d15bcc33a1a3ecb7e652520fa600)) ([8ac5edd](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/8ac5edd3cb8254047ee77a714025d5092bc77dc6))
* **tools/postgressql:** Add tool to list store procedure ([mcp-toolbox#​2156](https://redirect.github.com/googleapis/mcp-toolbox/issues/2156)) ([cf0fc51](https://redirect.github.com/googleapis/mcp-toolbox/commit/cf0fc515b57d9b84770076f3c0c5597c4597ef62)) ([8ac5edd](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/8ac5edd3cb8254047ee77a714025d5092bc77dc6))
* Add `allowed-hosts` flag ([mcp-toolbox#​2254](https://redirect.github.com/googleapis/mcp-toolbox/issues/2254)) ([17b41f6](https://redirect.github.com/googleapis/mcp-toolbox/commit/17b41f64531b8fe417c28ada45d1992ba430dc1b)) ([8ac5edd](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/8ac5edd3cb8254047ee77a714025d5092bc77dc6))
* Add `embeddingModel` support ([mcp-toolbox#​2121](https://redirect.github.com/googleapis/mcp-toolbox/issues/2121)) ([9c62f31](https://redirect.github.com/googleapis/mcp-toolbox/commit/9c62f313ff5edf0a3b5b8a3e996eba078fba4095)) ([8ac5edd](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/8ac5edd3cb8254047ee77a714025d5092bc77dc6))
* Add parameter default value to manifest ([mcp-toolbox#​2264](https://redirect.github.com/googleapis/mcp-toolbox/issues/2264)) ([9d1feca](https://redirect.github.com/googleapis/mcp-toolbox/commit/9d1feca10810fa42cb4c94a409252f1bd373ee36)) ([8ac5edd](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/8ac5edd3cb8254047ee77a714025d5092bc77dc6))
* Support combining prebuilt and custom tool configurations ([mcp-toolbox#​2188](https://redirect.github.com/googleapis/mcp-toolbox/issues/2188)) ([5788605](https://redirect.github.com/googleapis/mcp-toolbox/commit/57886058188aa5d2a51d5846a98bc6d8a650edd1)) ([8ac5edd](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/8ac5edd3cb8254047ee77a714025d5092bc77dc6))


### Bug Fixes

* **server:** Add `embeddingModel` config initialization ([mcp-toolbox#​2281](https://redirect.github.com/googleapis/mcp-toolbox/issues/2281)) ([a779975](https://redirect.github.com/googleapis/mcp-toolbox/commit/a7799757c9345f99b6d2717841fbf792d364e1a2)) ([8ac5edd](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/8ac5edd3cb8254047ee77a714025d5092bc77dc6))
* **sources/cloudgda:** Add import for cloudgda source ([mcp-toolbox#​2217](https://redirect.github.com/googleapis/mcp-toolbox/issues/2217)) ([7daa411](https://redirect.github.com/googleapis/mcp-toolbox/commit/7daa4111f4ebfb0a35319fd67a8f7b9f0f99efcf)) ([8ac5edd](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/8ac5edd3cb8254047ee77a714025d5092bc77dc6))
* **spanner:** Move list graphs validation to runtime ([mcp-toolbox#​2154](https://redirect.github.com/googleapis/mcp-toolbox/issues/2154)) ([914b3ee](https://redirect.github.com/googleapis/mcp-toolbox/commit/914b3eefda40a650efe552d245369e007277dab5)) ([8ac5edd](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/8ac5edd3cb8254047ee77a714025d5092bc77dc6))
* **tools/alloydb-wait-for-operation:** Fix connection message generation ([mcp-toolbox#​2228](https://redirect.github.com/googleapis/mcp-toolbox/issues/2228)) ([7053fbb](https://redirect.github.com/googleapis/mcp-toolbox/commit/7053fbb1953653143d39a8510916ea97a91022a6)) ([8ac5edd](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/8ac5edd3cb8254047ee77a714025d5092bc77dc6))
* **tools/alloydbainl:** Only add psv when NL Config Param is defined ([mcp-toolbox#​2265](https://redirect.github.com/googleapis/mcp-toolbox/issues/2265)) ([ef8f3b0](https://redirect.github.com/googleapis/mcp-toolbox/commit/ef8f3b02f2f38ce94a6ba9acf35d08b9469bef4e)) ([8ac5edd](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/8ac5edd3cb8254047ee77a714025d5092bc77dc6))
* **tools/looker:** Looker client OAuth nil pointer error ([mcp-toolbox#​2231](https://redirect.github.com/googleapis/mcp-toolbox/issues/2231)) ([268700b](https://redirect.github.com/googleapis/mcp-toolbox/commit/268700bdbf8281de0318d60ca613ed3672990b20)) ([8ac5edd](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/8ac5edd3cb8254047ee77a714025d5092bc77dc6))
* **tools/mongodb:** Removed sortPayload and sortParams ([mcp-toolbox#​1238](https://redirect.github.com/googleapis/mcp-toolbox/issues/1238)) ([c5a6daa](https://redirect.github.com/googleapis/mcp-toolbox/commit/c5a6daa7683d2f9be654300d977692c368e55e31)) ([8ac5edd](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/8ac5edd3cb8254047ee77a714025d5092bc77dc6))
* List tables tools null fix ([mcp-toolbox#​2107](https://redirect.github.com/googleapis/mcp-toolbox/issues/2107)) ([2b45266](https://redirect.github.com/googleapis/mcp-toolbox/commit/2b452665983154041d4cd0ed7d82532e4af682eb)) ([8ac5edd](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/8ac5edd3cb8254047ee77a714025d5092bc77dc6))

## [0.3.1](https://github.com/gemini-cli-extensions/mcp-toolbox/compare/0.3.0...0.3.1) (2025-12-08)


### Features

* **prebuilt/cloud-sql:** Add clone instance tool for cloud sql ([mcp-toolbox#​1845](https://redirect.github.com/googleapis/mcp-toolbox/issues/1845)) ([5e43630](https://redirect.github.com/googleapis/mcp-toolbox/commit/5e43630907aa2d7bc6818142483a33272eab060b)) ([c14e8b2](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/c14e8b25a08383551b4e92c2e527a82fa782fd8f))
* **serverless-spark:** Add create\_pyspark\_batch tool ([1bf0b51](https://redirect.github.com/googleapis/mcp-toolbox/commit/1bf0b51f033c956790be1577bf5310d0b17e9c12)) ([c14e8b2](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/c14e8b25a08383551b4e92c2e527a82fa782fd8f))
* **serverless-spark:** Add create\_spark\_batch tool ([17a9792](https://redirect.github.com/googleapis/mcp-toolbox/commit/17a979207dbc4fe70acd0ebda164d1a8d34c1ed3)) ([c14e8b2](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/c14e8b25a08383551b4e92c2e527a82fa782fd8f))
* **tool/mssql:** Set default host and port for MSSQL source ([mcp-toolbox#​1943](https://redirect.github.com/googleapis/mcp-toolbox/issues/1943)) ([7a9cc63](https://redirect.github.com/googleapis/mcp-toolbox/commit/7a9cc633768d9ae9a7ff8230002da69d6a36ca86)) ([c14e8b2](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/c14e8b25a08383551b4e92c2e527a82fa782fd8f))
* **tools/cloudsqlpg:** Add CloudSQL PostgreSQL pre-check tool ([mcp-toolbox#​1722](https://redirect.github.com/googleapis/mcp-toolbox/issues/1722)) ([8752e05](https://redirect.github.com/googleapis/mcp-toolbox/commit/8752e05ab6e98812d95673a6f1ff67e9a6ae48d2)) ([c14e8b2](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/c14e8b25a08383551b4e92c2e527a82fa782fd8f))
* **tools/postgres-list-publication-tables:** Add new postgres-list-publication-tables tool ([mcp-toolbox#​1919](https://redirect.github.com/googleapis/mcp-toolbox/issues/1919)) ([f4b1f0a](https://redirect.github.com/googleapis/mcp-toolbox/commit/f4b1f0a68000ca2fc0325f55a1905705417c38a2)) ([c14e8b2](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/c14e8b25a08383551b4e92c2e527a82fa782fd8f))
* **tools/postgres-list-tablespaces:** Add new postgres-list-tablespaces tool ([mcp-toolbox#​1934](https://redirect.github.com/googleapis/mcp-toolbox/issues/1934)) ([5ad7c61](https://redirect.github.com/googleapis/mcp-toolbox/commit/5ad7c6127b3e47504fc4afda0b7f3de1dff78b8b)) ([c14e8b2](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/c14e8b25a08383551b4e92c2e527a82fa782fd8f))
* **tools/postgres:** Add allowed-origins flag ([mcp-toolbox#​1984](https://redirect.github.com/googleapis/mcp-toolbox/issues/1984)) ([862868f](https://redirect.github.com/googleapis/mcp-toolbox/commit/862868f28476ea981575ce412faa7d6a03138f31)) ([c14e8b2](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/c14e8b25a08383551b4e92c2e527a82fa782fd8f))
* **tools/postgres:** Add list-query-stats and get-column-cardinality functions ([mcp-toolbox#​1976](https://redirect.github.com/googleapis/mcp-toolbox/issues/1976)) ([9f76026](https://redirect.github.com/googleapis/mcp-toolbox/commit/9f760269253a8cc92a357e995c6993ccc4a0fb7b)) ([c14e8b2](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/c14e8b25a08383551b4e92c2e527a82fa782fd8f))
* **tools/spanner-list-graph:** Tool impl + docs + tests ([mcp-toolbox#​1923](https://redirect.github.com/googleapis/mcp-toolbox/issues/1923)) ([a0f44d3](https://redirect.github.com/googleapis/mcp-toolbox/commit/a0f44d34ea3f044dd08501be616f70ddfd63ab45)) ([c14e8b2](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/c14e8b25a08383551b4e92c2e527a82fa782fd8f))
* **tools/spanner:** Add spanner list graphs to prebuiltconfigs ([mcp-toolbox#​2056](https://redirect.github.com/googleapis/mcp-toolbox/issues/2056)) ([0e7fbf4](https://redirect.github.com/googleapis/mcp-toolbox/commit/0e7fbf465c488397aa9d8cab2e55165fff4eb53c)) ([c14e8b2](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/c14e8b25a08383551b4e92c2e527a82fa782fd8f))
* Support alternate accessToken header name ([mcp-toolbox#​1968](https://redirect.github.com/googleapis/mcp-toolbox/issues/1968)) ([18017d6](https://redirect.github.com/googleapis/mcp-toolbox/commit/18017d6545335a6fc1c472617101c35254d9a597)) ([c14e8b2](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/c14e8b25a08383551b4e92c2e527a82fa782fd8f))
* Support for annotations ([mcp-toolbox#​2007](https://redirect.github.com/googleapis/mcp-toolbox/issues/2007)) ([ac21335](https://redirect.github.com/googleapis/mcp-toolbox/commit/ac21335f4e88ca52d954d7f8143a551a35661b94)) ([c14e8b2](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/c14e8b25a08383551b4e92c2e527a82fa782fd8f))


### Bug Fixes

* **tools/alloydb-postgres-list-tables:** Exclude google\_ml schema from list\_tables ([mcp-toolbox#​2046](https://redirect.github.com/googleapis/mcp-toolbox/issues/2046)) ([a03984c](https://redirect.github.com/googleapis/mcp-toolbox/commit/a03984cc15254c928f30085f8fa509ded6a79a0c)) ([c14e8b2](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/c14e8b25a08383551b4e92c2e527a82fa782fd8f))
* **tools/alloydbcreateuser:** Remove duplication of project praram ([mcp-toolbox#​2028](https://redirect.github.com/googleapis/mcp-toolbox/issues/2028)) ([730ac6d](https://redirect.github.com/googleapis/mcp-toolbox/commit/730ac6d22805fd50b4a675b74c1865f4e7689e7c)) ([c14e8b2](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/c14e8b25a08383551b4e92c2e527a82fa782fd8f))
* **tools/mongodb:** Remove `required` tag from the `canonical` field ([mcp-toolbox#​2099](https://redirect.github.com/googleapis/mcp-toolbox/issues/2099)) ([744214e](https://redirect.github.com/googleapis/mcp-toolbox/commit/744214e04cd12b11d166e6eb7da8ce4714904abc)) ([c14e8b2](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/c14e8b25a08383551b4e92c2e527a82fa782fd8f))
* Add import for firebirdsql ([mcp-toolbox#​2045](https://redirect.github.com/googleapis/mcp-toolbox/issues/2045)) ([fb7aae9](https://redirect.github.com/googleapis/mcp-toolbox/commit/fb7aae9d35b760d3471d8379642f835a0d84ec41)) ([c14e8b2](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/c14e8b25a08383551b4e92c2e527a82fa782fd8f))
* Correct FAQ to mention HTTP tools ([mcp-toolbox#​2036](https://redirect.github.com/googleapis/mcp-toolbox/issues/2036)) ([7b44237](https://redirect.github.com/googleapis/mcp-toolbox/commit/7b44237d4a21bfbf8d3cebe4d32a15affa29584d)) ([c14e8b2](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/c14e8b25a08383551b4e92c2e527a82fa782fd8f))
* Format BigQuery numeric output as decimal strings ([mcp-toolbox#​2084](https://redirect.github.com/googleapis/mcp-toolbox/issues/2084)) ([155bff8](https://redirect.github.com/googleapis/mcp-toolbox/commit/155bff80c1da4fae1e169e425fd82e1dc3373041)) ([c14e8b2](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/c14e8b25a08383551b4e92c2e527a82fa782fd8f))
* Set default annotations for tools in code if annotation not provided in yaml ([mcp-toolbox#​2049](https://redirect.github.com/googleapis/mcp-toolbox/issues/2049)) ([565460c](https://redirect.github.com/googleapis/mcp-toolbox/commit/565460c4ea8953dbe80070a8e469f957c0f7a70c)) ([c14e8b2](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/c14e8b25a08383551b4e92c2e527a82fa782fd8f))

## [0.3.0](https://github.com/gemini-cli-extensions/mcp-toolbox/compare/0.2.1...0.3.0) (2025-11-26)


### ⚠ BREAKING CHANGES

* **tools/spanner-list-tables:** Unmarshal `object_details` json string into map to make response have nested json ([mcp-toolbox#​1894](https://redirect.github.com/googleapis/mcp-toolbox/issues/1894)) ([446d62a](https://redirect.github.com/googleapis/mcp-toolbox/commit/446d62acd995d5128f52e9db254dd1c7138227c6))

### Features

* **tools/postgres:** Add `long_running_transactions`, `list_locks` and `replication_stats` tools ([mcp-toolbox#​1751](https://redirect.github.com/googleapis/mcp-toolbox/issues/1751)) ([5abad5d](https://redirect.github.com/googleapis/mcp-toolbox/commit/5abad5d56c6cc5ba86adc5253b948bf8230fa830)) ([a40592c](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/a40592cba476ea3c5b131429da3d6b8efe6b1f12))
* **tools/spanner-list-tables:** Unmarshal `object_details` json string into map to make response have nested json ([mcp-toolbox#​1894](https://redirect.github.com/googleapis/mcp-toolbox/issues/1894)) ([446d62a](https://redirect.github.com/googleapis/mcp-toolbox/commit/446d62acd995d5128f52e9db254dd1c7138227c6)) ([a40592c](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/a40592cba476ea3c5b131429da3d6b8efe6b1f12))


### Bug Fixes

* **tools:** Check for query execution error for pgxpool.Pool ([mcp-toolbox#​1969](https://redirect.github.com/googleapis/mcp-toolbox/issues/1969)) ([2bff138](https://redirect.github.com/googleapis/mcp-toolbox/commit/2bff1384a3570ef46bc03ebebc507923af261987)) ([a40592c](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/a40592cba476ea3c5b131429da3d6b8efe6b1f12))
* **tools/alloydbgetinstance:** Remove parameter duplication ([mcp-toolbox#​1993](https://redirect.github.com/googleapis/mcp-toolbox/issues/1993)) ([0e269a1](https://redirect.github.com/googleapis/mcp-toolbox/commit/0e269a1d125eed16a51ead27db4398e6e48cb948)) ([a40592c](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/a40592cba476ea3c5b131429da3d6b8efe6b1f12))

## [0.2.1](https://github.com/gemini-cli-extensions/mcp-toolbox/compare/0.2.0...0.2.1) (2025-11-14)


### Features

* **source/alloydb, source/cloud-sql-postgres,source/cloud-sql-mysql,source/cloud-sql-mssql:** Use project from env for alloydb and cloud sql control plane tools ([mcp-toolbox#​1588](https://redirect.github.com/googleapis/mcp-toolbox/issues/1588)) ([12bdd95](https://redirect.github.com/googleapis/mcp-toolbox/commit/12bdd954597e49d3ec6b247cc104584c5a4d1943)) ([e57d7a4](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/e57d7a40732ed7ca592f6415a96d79ea3ebddc08))
* **source/mysql:** Set default host and port for MySQL source ([mcp-toolbox#​1922](https://redirect.github.com/googleapis/mcp-toolbox/issues/1922)) ([2c228ef](https://redirect.github.com/googleapis/mcp-toolbox/commit/2c228ef4f2d4cb8dfc41e845466bfe3566d141a1)) ([e57d7a4](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/e57d7a40732ed7ca592f6415a96d79ea3ebddc08))
* **source/Postgresql:** Set default host and port for Postgresql  source ([mcp-toolbox#​1927](https://redirect.github.com/googleapis/mcp-toolbox/issues/1927)) ([7e6e88a](https://redirect.github.com/googleapis/mcp-toolbox/commit/7e6e88a21f2b9b60e0d645cdde33a95892d31a04)) ([e57d7a4](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/e57d7a40732ed7ca592f6415a96d79ea3ebddc08))
* **tool/looker-generate-embed-url:** Adding generate embed url tool ([mcp-toolbox#​1877](https://redirect.github.com/googleapis/mcp-toolbox/issues/1877)) ([ef63860](https://redirect.github.com/googleapis/mcp-toolbox/commit/ef63860559798fbad54c1051d9f53bce42d66464)) ([e57d7a4](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/e57d7a40732ed7ca592f6415a96d79ea3ebddc08))
* **tools/postgres:** Add `list_triggers`, `database_overview` tools for postgres ([mcp-toolbox#​1912](https://redirect.github.com/googleapis/mcp-toolbox/issues/1912)) ([a4c9287](https://redirect.github.com/googleapis/mcp-toolbox/commit/a4c9287aecf848faa98d973a9ce5b13fa309a58e)) ([e57d7a4](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/e57d7a40732ed7ca592f6415a96d79ea3ebddc08))
* **tools/postgres:** Add list\_indexes, list\_sequences tools for postgres ([mcp-toolbox#​1765](https://redirect.github.com/googleapis/mcp-toolbox/issues/1765)) ([897c63d](https://redirect.github.com/googleapis/mcp-toolbox/commit/897c63dcea43226262d2062088c59f2d1068fca7)) ([e57d7a4](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/e57d7a40732ed7ca592f6415a96d79ea3ebddc08))
* Added prompt support for toolbox ([mcp-toolbox#​1798](https://redirect.github.com/googleapis/mcp-toolbox/issues/1798)) ([cd56ea4](https://redirect.github.com/googleapis/mcp-toolbox/commit/cd56ea44fbdd149fcb92324e70ee36ac747635db)) ([e57d7a4](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/e57d7a40732ed7ca592f6415a96d79ea3ebddc08))

## [0.2.0](https://github.com/gemini-cli-extensions/mcp-toolbox/compare/0.1.3...0.2.0) (2025-11-07)


### ⚠ BREAKING CHANGES

* **tools/bigquery-analyze-contribution:** Add allowed dataset support ([mcp-toolbox#​1675](https://redirect.github.com/googleapis/mcp-toolbox/issues/1675)) ([ef28e39](https://redirect.github.com/googleapis/mcp-toolbox/commit/ef28e39e90b21287ca8e69b99f4e792c78e9d31f))
* **tools/bigquery-get-dataset-info:** add allowed dataset support ([mcp-toolbox#​1654](https://redirect.github.com/googleapis/mcp-toolbox/issues/1654))
* **tools/alloydbainl:** update AlloyDB AI NL statement order ([mcp-toolbox#​1753](https://redirect.github.com/googleapis/mcp-toolbox/issues/1753))

### Features

* **cloud-healthcare:** Add support for healthcare source, tool and prebuilt config ([mcp-toolbox#​1853](https://redirect.github.com/googleapis/mcp-toolbox/issues/1853)) ([1f833fb](https://redirect.github.com/googleapis/mcp-toolbox/commit/1f833fb1a124e23819ddfec476f2e63ef31dd22f)) ([a7ed381](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/a7ed3817af6bd2e5b6ae1f680c3fd92907811668))
* **elasticsearch:** Add Elasticsearch source and tools ([mcp-toolbox#​1109](https://redirect.github.com/googleapis/mcp-toolbox/issues/1109)) ([5367285](https://redirect.github.com/googleapis/mcp-toolbox/commit/5367285e91ddda99ae7261d8ed4b025f975d1453)) ([a7ed381](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/a7ed3817af6bd2e5b6ae1f680c3fd92907811668))
* **mindsdb:** Add MindsDB Source and Tools  ([mcp-toolbox#​878](https://redirect.github.com/googleapis/mcp-toolbox/issues/878)) ([1b2cca9](https://redirect.github.com/googleapis/mcp-toolbox/commit/1b2cca9faa6f7bacbeb5d25634ce3bf61067de16)) ([a7ed381](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/a7ed3817af6bd2e5b6ae1f680c3fd92907811668))
* **singlestore:** Add SingleStore Source and Tools ([mcp-toolbox#​1333](https://redirect.github.com/googleapis/mcp-toolbox/issues/1333)) ([40b9dba](https://redirect.github.com/googleapis/mcp-toolbox/commit/40b9dbab088add05a66995abb1c71a9345b8f7e5)) ([a7ed381](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/a7ed3817af6bd2e5b6ae1f680c3fd92907811668))
* **source/bigquery:** Add client cache for user-passed credentials ([mcp-toolbox#​1119](https://redirect.github.com/googleapis/mcp-toolbox/issues/1119)) ([cf7012a](https://redirect.github.com/googleapis/mcp-toolbox/commit/cf7012a82bb5c77309da3a26e563a5015786aa69)) ([a7ed381](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/a7ed3817af6bd2e5b6ae1f680c3fd92907811668))
* **source/bigquery:** Add service account impersonation support for bigquery ([mcp-toolbox#​1641](https://redirect.github.com/googleapis/mcp-toolbox/issues/1641)) ([e09d182](https://redirect.github.com/googleapis/mcp-toolbox/commit/e09d182f88bf697a169428f477aebc9f1741e35f)) ([a7ed381](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/a7ed3817af6bd2e5b6ae1f680c3fd92907811668))
* **tools/alloydbainl:** update AlloyDB AI NL statement order ([mcp-toolbox#​1753](https://redirect.github.com/googleapis/mcp-toolbox/issues/1753)) ([a7ed381](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/a7ed3817af6bd2e5b6ae1f680c3fd92907811668))
* **tools/bigquery-analyze-contribution:** Add allowed dataset support ([mcp-toolbox#​1675](https://redirect.github.com/googleapis/mcp-toolbox/issues/1675)) ([ef28e39](https://redirect.github.com/googleapis/mcp-toolbox/commit/ef28e39e90b21287ca8e69b99f4e792c78e9d31f)) ([a7ed381](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/a7ed3817af6bd2e5b6ae1f680c3fd92907811668))
* **tools/bigquery-analyze-contribution:** Add allowed dataset support ([mcp-toolbox#​1675](https://redirect.github.com/googleapis/mcp-toolbox/issues/1675)) ([ef28e39](https://redirect.github.com/googleapis/mcp-toolbox/commit/ef28e39e90b21287ca8e69b99f4e792c78e9d31f)) ([a7ed381](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/a7ed3817af6bd2e5b6ae1f680c3fd92907811668))
* **tools/bigquery-get-dataset-info:** add allowed dataset support ([mcp-toolbox#​1654](https://redirect.github.com/googleapis/mcp-toolbox/issues/1654)) ([a7ed381](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/a7ed3817af6bd2e5b6ae1f680c3fd92907811668))
* **tools/bigquery-get-dataset-info:** Add allowed dataset support ([mcp-toolbox#​1654](https://redirect.github.com/googleapis/mcp-toolbox/issues/1654)) ([a2006ad](https://redirect.github.com/googleapis/mcp-toolbox/commit/a2006ad57718ebad3de5c6850e9c6a5a763808ec)) ([a7ed381](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/a7ed3817af6bd2e5b6ae1f680c3fd92907811668))
* **tools/looker-run-dashboard:** New `run_dashboard` tool ([mcp-toolbox#​1858](https://redirect.github.com/googleapis/mcp-toolbox/issues/1858)) ([30857c2](https://redirect.github.com/googleapis/mcp-toolbox/commit/30857c2294bb14961d3be49e2c368c69ecf844ec)) ([a7ed381](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/a7ed3817af6bd2e5b6ae1f680c3fd92907811668))
* **tools/looker-run-look:** Modify run\_look to show query origin ([mcp-toolbox#​1860](https://redirect.github.com/googleapis/mcp-toolbox/issues/1860)) ([991e539](https://redirect.github.com/googleapis/mcp-toolbox/commit/991e539f9c7978fa618ada3179a0b656c33ff501)) ([a7ed381](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/a7ed3817af6bd2e5b6ae1f680c3fd92907811668))
* **tools/looker:** Tools to retrieve the connections, schemas, databases, and column metadata from a looker system. ([mcp-toolbox#​1804](https://redirect.github.com/googleapis/mcp-toolbox/issues/1804)) ([d7d1b03](https://redirect.github.com/googleapis/mcp-toolbox/commit/d7d1b03f3b746ed748d67f67e833457d55c846ab)) ([a7ed381](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/a7ed3817af6bd2e5b6ae1f680c3fd92907811668))
* **tools/mongodb:** Make MongoDB tools' `filterParams` field optional ([mcp-toolbox#​1614](https://redirect.github.com/googleapis/mcp-toolbox/issues/1614)) ([208ab92](https://redirect.github.com/googleapis/mcp-toolbox/commit/208ab92eb377b538a99330a415ecc18790b077b7)) ([a7ed381](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/a7ed3817af6bd2e5b6ae1f680c3fd92907811668))
* **tools/neo4j-execute-cypher:** Add dry\_run parameter to validate Cypher queries ([mcp-toolbox#​1769](https://redirect.github.com/googleapis/mcp-toolbox/issues/1769)) ([f475da6](https://redirect.github.com/googleapis/mcp-toolbox/commit/f475da63ce1b65387b503ac497eca47635452723)) ([a7ed381](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/a7ed3817af6bd2e5b6ae1f680c3fd92907811668))
* **tools/postgres-list-schemas:** Add new postgres-list-schemas tool ([mcp-toolbox#​1741](https://redirect.github.com/googleapis/mcp-toolbox/issues/1741)) ([1a19cac](https://redirect.github.com/googleapis/mcp-toolbox/commit/1a19cac7cd89ed70291eb55e190370fe7b2c1aba)) ([a7ed381](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/a7ed3817af6bd2e5b6ae1f680c3fd92907811668))
* **tools/postgres-list-views:** Add new postgres-list-views tool ([mcp-toolbox#​1709](https://redirect.github.com/googleapis/mcp-toolbox/issues/1709)) ([e8c7fe0](https://redirect.github.com/googleapis/mcp-toolbox/commit/e8c7fe0994fedcb9be78d461fab3c98cc6bd86b2)) ([a7ed381](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/a7ed3817af6bd2e5b6ae1f680c3fd92907811668))
* **tools/serverless-spark:** Add cancel-batch tool ([mcp-toolbox#​1827](https://redirect.github.com/googleapis/mcp-toolbox/pull/1827))([2881683](https://redirect.github.com/googleapis/mcp-toolbox/commit/28816832265250de97d84e6ba38bf6c35e040796)) ([a7ed381](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/a7ed3817af6bd2e5b6ae1f680c3fd92907811668))
* **tools/serverless-spark:** Add get\_batch tool ([mcp-toolbox#​1783](https://redirect.github.com/googleapis/mcp-toolbox/pull/1783))([7ad1072](https://redirect.github.com/googleapis/mcp-toolbox/commit/7ad10720b4638324cd77d8aa410cbd1ccf0cc93f)) ([a7ed381](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/a7ed3817af6bd2e5b6ae1f680c3fd92907811668))
* **tools/serverless-spark:** Add serverless-spark source with list\_batches tool ([mcp-toolbox#​1690](https://redirect.github.com/googleapis/mcp-toolbox/pull/1690))([816dbce](https://redirect.github.com/googleapis/mcp-toolbox/commit/816dbce268392046e54767732bd31488c6e89bdb)) ([a7ed381](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/a7ed3817af6bd2e5b6ae1f680c3fd92907811668))
* Support `excludeValues` for parameters ([mcp-toolbox#​1818](https://redirect.github.com/googleapis/mcp-toolbox/issues/1818)) ([a8e98dc](https://redirect.github.com/googleapis/mcp-toolbox/commit/a8e98dc99d208e8b37a3bc4d1ab4749b5154ed36)) ([a7ed381](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/a7ed3817af6bd2e5b6ae1f680c3fd92907811668))


### Bug Fixes

* **cloudmonitoring:** Populate `authRequired` in tool manifest ([mcp-toolbox#​1800](https://redirect.github.com/googleapis/mcp-toolbox/issues/1800)) ([954152c](https://redirect.github.com/googleapis/mcp-toolbox/commit/954152c7928bf0da9be221e011e32f74bc4cebbc)) ([a7ed381](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/a7ed3817af6bd2e5b6ae1f680c3fd92907811668))
* **source/cloud-sql-mssql:** Remove `ipAddress` field ([mcp-toolbox#​1822](https://redirect.github.com/googleapis/mcp-toolbox/issues/1822)) ([38d535d](https://redirect.github.com/googleapis/mcp-toolbox/commit/38d535de34cfedd6828a01d9dcd25daf1bad7306)) ([a7ed381](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/a7ed3817af6bd2e5b6ae1f680c3fd92907811668))
* **tools/alloydbainl:** AlloyDB AI NL execute\_sql statement order ([mcp-toolbox#​1753](https://redirect.github.com/googleapis/mcp-toolbox/issues/1753)) ([9723cad](https://redirect.github.com/googleapis/mcp-toolbox/commit/9723cadaa181a76d8fdda65a6254f6c887c3cf57)) ([a7ed381](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/a7ed3817af6bd2e5b6ae1f680c3fd92907811668))
* **tools/postgres-execute-sql:** Do not ignore SQL failure ([mcp-toolbox#​1829](https://redirect.github.com/googleapis/mcp-toolbox/issues/1829)) ([8984287](https://redirect.github.com/googleapis/mcp-toolbox/commit/898428759c2a1a384bea8939605cf0914d129bec)) ([a7ed381](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/a7ed3817af6bd2e5b6ae1f680c3fd92907811668))
* Bigquery execute\_sql to assign values to array ([mcp-toolbox#​1884](https://redirect.github.com/googleapis/mcp-toolbox/issues/1884)) ([559e2a2](https://redirect.github.com/googleapis/mcp-toolbox/commit/559e2a22e0db20bb947702e13140ce869b5865a7)) ([a7ed381](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/a7ed3817af6bd2e5b6ae1f680c3fd92907811668))
* Instructions to quote filters that include commas ([mcp-toolbox#​1794](https://redirect.github.com/googleapis/mcp-toolbox/issues/1794)) ([4b01720](https://redirect.github.com/googleapis/mcp-toolbox/commit/4b0172083c0dd4c71098d4e0ab5fa0b16ea0d830)) ([a7ed381](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/a7ed3817af6bd2e5b6ae1f680c3fd92907811668))
* Update debug logs statements ([mcp-toolbox#​1828](https://redirect.github.com/googleapis/mcp-toolbox/issues/1828)) ([3cff915](https://redirect.github.com/googleapis/mcp-toolbox/commit/3cff915e22c3a5e4e296607f83ae6409b896c9a9)) ([a7ed381](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/a7ed3817af6bd2e5b6ae1f680c3fd92907811668))

## [0.1.3](https://github.com/gemini-cli-extensions/mcp-toolbox/compare/0.1.2...0.1.3) (2025-10-27)


### Features

* **tools/looker:** Tools to allow the agent to retrieve, create, modify, and delete LookML project files. ([#1673](https://redirect.github.com/googleapis/mcp-toolbox/issues/1673)) ([089081f](https://redirect.github.com/googleapis/mcp-toolbox/commit/089081feb0e32f9eb65d00df5987392d413a4081)) ([f006c4c](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/f006c4c765c91f678e7055c55e43828e60962da6))
* Support `allowedValues`, `escape`, `minValue` and `maxValue` for parameters ([#1770](https://redirect.github.com/googleapis/mcp-toolbox/issues/1770)) ([eaf7740](https://redirect.github.com/googleapis/mcp-toolbox/commit/eaf77406fd386c12315d67eb685dc69e0415c516)) ([f006c4c](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/f006c4c765c91f678e7055c55e43828e60962da6))


### Bug Fixes

* **sources/mysql:** Escape mysql user agent ([#1707](https://redirect.github.com/googleapis/mcp-toolbox/issues/1707)) ([eeb694c](https://redirect.github.com/googleapis/mcp-toolbox/commit/eeb694c20facc40a38bfa67073c4cb1f3dd657ff)) ([f006c4c](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/f006c4c765c91f678e7055c55e43828e60962da6))
* **sources/mysql:** Escape program\_name for MySQL ([#1717](https://redirect.github.com/googleapis/mcp-toolbox/issues/1717)) ([02f7f8a](https://redirect.github.com/googleapis/mcp-toolbox/commit/02f7f8af979057efe99fd138cb1b958130355b68)) ([f006c4c](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/f006c4c765c91f678e7055c55e43828e60962da6))
* **tools/http:** Allow 2xx status code on tool invocation ([#1761](https://redirect.github.com/googleapis/mcp-toolbox/issues/1761)) ([a06d0d8](https://redirect.github.com/googleapis/mcp-toolbox/commit/a06d0d8735fbec29bea97457248845a8c6b4aa3c)) ([f006c4c](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/f006c4c765c91f678e7055c55e43828e60962da6))
* **tools/http:** Omit optional nil query parameters ([#1762](https://redirect.github.com/googleapis/mcp-toolbox/issues/1762)) ([bd16ba3](https://redirect.github.com/googleapis/mcp-toolbox/commit/bd16ba3921e6177065780e5f29870859b8e18e4f)) ([f006c4c](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/f006c4c765c91f678e7055c55e43828e60962da6))
* **tools/looker:** Looker file content calls should not use url.QueryEscape ([#1758](https://redirect.github.com/googleapis/mcp-toolbox/issues/1758)) ([336de1b](https://redirect.github.com/googleapis/mcp-toolbox/commit/336de1bd04b869d322c0fd1f4667eb652159d791)) ([f006c4c](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/f006c4c765c91f678e7055c55e43828e60962da6))

## [0.1.2](https://github.com/gemini-cli-extensions/mcp-toolbox/compare/0.1.1...0.1.2) (2025-10-17)


### Features

* **deps:** update dependency googleapis/mcp-toolbox to v0.17.0 ([#33](https://github.com/gemini-cli-extensions/mcp-toolbox/issues/33)) ([5745a8f](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/5745a8fc96336cbedc3d99cdecaedd2721ea6ce5))

## [0.1.1](https://github.com/gemini-cli-extensions/mcp-toolbox/compare/0.1.0...0.1.1) (2025-09-30)


### Features

* additional instructions for the context file ([#25](https://github.com/gemini-cli-extensions/mcp-toolbox/issues/25)) ([1413efc](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/1413efcd66b03224705429eefdfb58e4ebf79f40))
* standardize mcp server names ([#23](https://github.com/gemini-cli-extensions/mcp-toolbox/issues/23)) ([e58b860](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/e58b86093975ddbbad5de7c1382a73187fa66117))

## 0.1.0 (2025-09-21)


### Miscellaneous Chores

* make binary executable ([#7](https://github.com/gemini-cli-extensions/mcp-toolbox/issues/7)) ([e15c109](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/e15c109a8b91b826d63cab634777d831c147879f))
* release 0.1.0 ([#6](https://github.com/gemini-cli-extensions/mcp-toolbox/issues/6)) ([6186ee5](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/6186ee50ecf689c037a297d84816fa8b39b5314a))
* update codeowners ([#4](https://github.com/gemini-cli-extensions/mcp-toolbox/issues/4)) ([ed127cf](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/ed127cfcf07f45287f38d8d0212e4b86274fa32a))


### Documentation

* Update gemini-extension.json ([#1](https://github.com/gemini-cli-extensions/mcp-toolbox/issues/1)) ([3395560](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/3395560c7382727f5a006cc08de6ec91256e8286))
* update readme to remove disclaimer and update context file ([#2](https://github.com/gemini-cli-extensions/mcp-toolbox/issues/2)) ([02adcb2](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/02adcb2a0844c7f23dd1e42259a033edec08a814))
* Update README.md ([#5](https://github.com/gemini-cli-extensions/mcp-toolbox/issues/5)) ([9996d10](https://github.com/gemini-cli-extensions/mcp-toolbox/commit/9996d105887d7c09ab58ce54419c98bcc4e0f655))
