# Changelog

## [0.1.6](https://github.com/gemini-cli-extensions/bigquery-conversational-analytics/compare/0.1.5...0.1.6) (2026-01-30)


### Features

* Support custom scopes and maxQueryResultRows ([#77](https://github.com/gemini-cli-extensions/bigquery-conversational-analytics/issues/77)) ([c38438e](https://github.com/gemini-cli-extensions/bigquery-conversational-analytics/commit/c38438e8d4296d98ab2fa52e3b61cfe518fec3a4))

## [0.1.5](https://github.com/gemini-cli-extensions/bigquery-conversational-analytics/compare/0.1.4...0.1.5) (2026-01-28)


### Features

* add Configuration settings ([#72](https://github.com/gemini-cli-extensions/bigquery-conversational-analytics/issues/72)) ([27a9100](https://github.com/gemini-cli-extensions/bigquery-conversational-analytics/commit/27a9100b91b45d2dc49b48b29b7565551de21d80))
* **deps:** update dependency googleapis/genai-toolbox to v0.26.0 ([#74](https://github.com/gemini-cli-extensions/bigquery-conversational-analytics/issues/74)) ([124a489](https://github.com/gemini-cli-extensions/bigquery-conversational-analytics/commit/124a4898581b220e2e0dd9772484a7808d161c84))

## [0.1.4](https://github.com/gemini-cli-extensions/bigquery-conversational-analytics/compare/0.1.3...0.1.4) (2026-01-22)


### Features

* **deps:** update dependency googleapis/genai-toolbox to v0.25.0 ([#69](https://github.com/gemini-cli-extensions/bigquery-conversational-analytics/issues/69)) ([bc0ac06](https://github.com/gemini-cli-extensions/bigquery-conversational-analytics/commit/bc0ac06dd17f1bb81f47fa116ec31b67677322e6))

## [0.1.3](https://github.com/gemini-cli-extensions/bigquery-conversational-analytics/compare/0.1.2...0.1.3) (2025-12-30)


### Features

* **deps:** update dependency googleapis/genai-toolbox to v0.24.0 ([#67](https://github.com/gemini-cli-extensions/bigquery-conversational-analytics/issues/67)) ([888a7d7](https://github.com/gemini-cli-extensions/bigquery-conversational-analytics/commit/888a7d7329d1027acae4743d3b84a79554383758))

## [0.1.2](https://github.com/gemini-cli-extensions/bigquery-conversational-analytics/compare/0.1.1...0.1.2) (2025-12-12)


### Features

* **deps:** update dependency googleapis/genai-toolbox to v0.23.0 ([#63](https://github.com/gemini-cli-extensions/bigquery-conversational-analytics/issues/63)) ([7c942a5](https://github.com/gemini-cli-extensions/bigquery-conversational-analytics/commit/7c942a5fd79e45963db59e70d6d7c59475e6b49d))

## [0.1.1](https://github.com/gemini-cli-extensions/bigquery-conversational-analytics/compare/0.1.0...0.1.1) (2025-09-30)


### Features

* additional instructions for the context file ([#28](https://github.com/gemini-cli-extensions/bigquery-conversational-analytics/issues/28)) ([0014c2b](https://github.com/gemini-cli-extensions/bigquery-conversational-analytics/commit/0014c2b51e50339c3f8a551a32f2da38d3e830f9))
* standardize mcp server names ([#25](https://github.com/gemini-cli-extensions/bigquery-conversational-analytics/issues/25)) ([c833e93](https://github.com/gemini-cli-extensions/bigquery-conversational-analytics/commit/c833e93ceee5755da04daea4eba571e76e9e17bb))

## 0.1.0 (2025-09-22)


### Features

* add the BigQuery Conversational Analytics Extension ([#7](https://github.com/gemini-cli-extensions/bigquery-conversational-analytics/issues/7)) ([c3c552e](https://github.com/gemini-cli-extensions/bigquery-conversational-analytics/commit/c3c552e50ada6ba2dca2cbc538270a7668235a50))
